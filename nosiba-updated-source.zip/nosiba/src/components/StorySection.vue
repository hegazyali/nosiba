<script setup>
import { siteConfig } from '../data/siteConfig.js'
import { mediaAsset } from '../data/products.js'
import { useLanguage } from '../composables/useLanguage.js'
const { t } = useLanguage()
const storyImage = mediaAsset('assets/look-04.webp')
</script>
<template>
  <section class="section-pad"><div class="container-wide story-grid"><div class="story-image reveal"><img :src="storyImage" alt="Temporary editorial abaya image" loading="lazy" /></div><div class="story-copy reveal"><span class="section-eyebrow">{{ t('The house', 'الدار') }}</span><h2>{{ t('Made in Egypt. Chosen for the everyday.', 'صُنع في مصر. واختير ليومك.') }}</h2><p>{{ t('Nosiba is an Egyptian clothing factory established in 2024 and specialized in abayas. From Warraq, Giza, we are shaping a considered space for abayas that feel composed, personal, and easy to return to.', 'نُسيبه مصنع ملابس مصري تأسس عام ٢٠٢٤ ومتخصص في العبايات. من الوراق في الجيزة، نصنع مساحة مدروسة لعبايات هادئة، شخصية، وسهلة الاختيار كل يوم.') }}</p><ul class="rule-list"><li><span>{{ t('Established', 'التأسيس') }}</span><span>{{ siteConfig.established }}</span></li><li><span>{{ t('Specialization', 'التخصص') }}</span><span>{{ t(siteConfig.specialization, siteConfig.specializationAr) }}</span></li><li><span>{{ t('Location', 'الموقع') }}</span><span>{{ t('Warraq, Giza', 'الوراق، الجيزة') }}</span></li></ul></div></div></section>
</template>
