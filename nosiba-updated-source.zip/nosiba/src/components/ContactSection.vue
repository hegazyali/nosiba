<script setup>
import { RouterLink } from 'vue-router'
import { siteConfig } from '../data/siteConfig.js'
import { useLanguage } from '../composables/useLanguage.js'
import { useWhatsApp } from '../composables/useWhatsApp.js'

const { t, language } = useLanguage()
const { buildUrl } = useWhatsApp()
</script>

<template>
  <section class="section-pad pt-0">
    <div class="container-wide">
      <div class="section-heading">
        <div>
          <span class="section-eyebrow">{{ t('Come by', 'تواصلي معنا') }}</span>
          <h2 class="mt-3">{{ t('A real place for a real conversation.', 'مكان حقيقي لمحادثة حقيقية.') }}</h2>
        </div>
        <p>{{ t('Find the factory in Warraq, Giza, or reach us directly for collection questions and wholesale conversations.', 'تجدين المصنع في الوراق، الجيزة، أو تواصلي معنا مباشرةً لأسئلة المجموعة والتعامل مع المتاجر.') }}</p>
      </div>
      <div class="contact-grid">
        <div>
          <div class="contact-card">
            <h3>{{ t('Factory address', 'عنوان المصنع') }}</h3>
            <p>{{ t('Egypt · Giza · Warraq · Army Street', 'مصر · الجيزة · الوراق · شارع الجيش') }}</p>
          </div>
          <div class="contact-card">
            <h3>{{ t('Working days', 'أيام العمل') }}</h3>
            <p>{{ t(`${siteConfig.workingDays} · Sunday: Closed`, `${siteConfig.workingDaysAr} · الأحد إجازة`) }}</p>
          </div>
        </div>
        <div>
          <div class="notice-card mb-4">{{ t('Shipping coverage: All Egypt. Delivery cost and timing are confirmed manually after your WhatsApp conversation.', 'التوصيل: كل أنحاء مصر. يتم تأكيد التكلفة والموعد يدوياً بعد محادثة واتساب.') }}</div>
          <div class="d-flex flex-wrap gap-2">
            <a class="btn btn-nosiba" :href="`tel:${siteConfig.phone}`">{{ t('Call the factory', 'اتصلي بالمصنع') }}</a>
            <a class="btn btn-outline-nosiba" :href="buildUrl({ lang: language })" target="_blank" rel="noopener">{{ t('WhatsApp us', 'واتساب') }}</a>
            <RouterLink class="btn btn-outline-nosiba" to="/contact">{{ t('More contact details', 'تفاصيل التواصل') }}</RouterLink>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
