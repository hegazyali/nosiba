import { computed, ref } from 'vue'

const items = ref([])

export const useOrderCollection = () => {
  const count = computed(() => items.value.reduce((sum, item) => sum + item.quantity, 0))
  const addItem = (product, size, color, quantity = 1) => {
    const existing = items.value.find((item) => item.product.id === product.id && item.size === size && item.color === color)
    if (existing) existing.quantity += quantity
    else items.value.push({ product, size, color, quantity })
  }
  const updateQuantity = (index, quantity) => { if (quantity <= 0) items.value.splice(index, 1); else items.value[index].quantity = quantity }
  const removeItem = (index) => items.value.splice(index, 1)
  const clear = () => { items.value.splice(0) }
  return { items, count, addItem, updateQuantity, removeItem, clear }
}
