<script setup>
import { computed, ref, watch } from 'vue'
import { useLanguage } from '../composables/useLanguage.js'
const props = defineProps({ product: { type: Object, required: true } })
const { isArabic } = useLanguage()
const active = ref(0)
const media = computed(() => [
  ...(props.product.images || []).map((src) => ({ type: 'image', src })),
  ...(props.product.videos || []).map((src) => ({ type: 'video', src })),
])
const activeMedia = computed(() => media.value[active.value] || media.value[0])
watch(() => props.product.slug, () => { active.value = 0 })
</script>
<template>
  <div class="detail-gallery"><div class="detail-thumbs"><button v-for="(item, index) in media" :key="`${item.type}-${item.src}`" class="detail-thumb" :class="{ 'is-active': active === index }" type="button" :aria-label="item.type === 'video' ? 'Play product video' : `${isArabic ? product.nameAr : product.name} ${index + 1}`" @click="active = index"><img v-if="item.type === 'image'" :src="item.src" :alt="`${isArabic ? product.nameAr : product.name} ${index + 1}`" loading="lazy" /><span v-else class="video-thumb">▶</span></button></div><div class="detail-main-image"><img v-if="activeMedia?.type === 'image'" :src="activeMedia.src" :alt="isArabic ? product.nameAr : product.name" /><video v-else-if="activeMedia" :src="activeMedia.src" controls playsinline preload="metadata" :aria-label="`${isArabic ? product.nameAr : product.name} video`"></video></div></div>
</template>
