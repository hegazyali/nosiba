<script setup>
import { RouterLink } from 'vue-router'
import { useLanguage } from '../composables/useLanguage.js'
const props = defineProps({ categories: { type: Array, default: () => [] } })
const { isArabic, t } = useLanguage()
</script>
<template>
  <div class="category-grid">
    <RouterLink v-for="category in props.categories" :key="category.id" class="category-card reveal" :to="{ path: '/shop', query: { category: category.name } }">
      <img :src="category.image" :alt="isArabic ? category.nameAr : category.name" loading="lazy" />
      <div class="category-card-content"><div><small>{{ category.count }} {{ t('prototype pieces', 'قطع تجريبية') }}</small><h3>{{ isArabic ? category.nameAr : category.name }}</h3></div><span class="arrow-chip" aria-hidden="true">↗</span></div>
    </RouterLink>
  </div>
</template>
