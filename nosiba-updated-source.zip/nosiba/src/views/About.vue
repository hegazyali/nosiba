<script setup>
import { onMounted } from 'vue'
import StorySection from '../components/StorySection.vue'
import { useLanguage } from '../composables/useLanguage.js'
const { t } = useLanguage()
onMounted(() => { document.title = 'Nosiba — About' })
</script>
<template>
  <div><section class="page-hero"><div class="container-wide"><span class="section-eyebrow">{{ t('The house', 'الدار') }}</span><h1 class="mt-3">{{ t('About Nosiba.', 'عن نُسيبه.') }}</h1><p>{{ t('An Egyptian clothing factory, established in 2024 and specialized in abayas.', 'مصنع ملابس مصري تأسس عام ٢٠٢٤ ومتخصص في العبايات.') }}</p></div></section><StorySection /><section class="section-pad pt-0"><div class="container-wide"><div class="notice-card">{{ t('This prototype intentionally avoids unverified claims about capacity, certifications, reviews, customers, or sustainability. Those details can be added when Nosiba supplies them.', 'تتجنب هذه النسخة التجريبية عمداً أي ادعاءات غير مؤكدة عن الطاقة الإنتاجية أو الشهادات أو التقييمات أو العملاء أو الاستدامة. يمكن إضافة هذه التفاصيل عند تزويد نُسيبه بها.') }}</div></div></section></div>
</template>
