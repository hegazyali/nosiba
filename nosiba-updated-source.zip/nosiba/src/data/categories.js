import { products } from './products.js'

export const categories = [...new Set(products.map((product) => product.category))].map((name, index) => {
  const first = products.find((product) => product.category === name)
  return { id: name.toLowerCase().replace(/\s+/g, '-'), name, nameAr: first.categoryAr, image: first.images[0], count: products.filter((product) => product.category === name).length, index }
})
