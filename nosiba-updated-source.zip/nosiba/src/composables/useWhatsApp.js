import { siteConfig } from '../data/siteConfig.js'
import { formatPrice } from '../data/products.js'

export const useWhatsApp = () => {
  const buildMessage = ({ product, size, color, quantity = 1, lang = 'en', items = [] } = {}) => {
    if (items.length) {
      const lines = items.map((item) => `${lang === 'ar' ? item.product.nameAr : item.product.name} · ${item.quantity}x · ${item.size || (lang === 'ar' ? 'يُحدد لاحقاً' : 'To confirm')} · ${item.color || (lang === 'ar' ? 'يُحدد لاحقاً' : 'To confirm')} · ${formatPrice(item.product.price, lang)}`)
      return lang === 'ar'
        ? `مرحباً، أرغب في طلب القطع التالية من نُسيبه:\n\n${lines.join('\n')}\n\nيرجى تأكيد الأسعار والتفاصيل.`
        : `Hello, I would like to order the following from Nosiba:\n\n${lines.join('\n')}\n\nPlease confirm prices and details.`
    }
    if (!product) {
      return lang === 'ar' ? 'مرحباً، أود معرفة المزيد عن مجموعة نُسيبه.' : 'Hello, I would like to learn more about the Nosiba collection.'
    }
    const name = lang === 'ar' ? product.nameAr : product.name
    const price = formatPrice(product.price, lang)
    return lang === 'ar'
      ? `مرحباً، أرغب في طلب:\n\nالمنتج: ${name}\nالمقاس: ${size || 'يُحدد لاحقاً'}\nاللون: ${color || 'يُحدد لاحقاً'}\nالكمية: ${quantity}\nالسعر: ${price}`
      : `Hello, I would like to order:\n\nProduct: ${name}\nSize: ${size || 'To confirm'}\nColor: ${color || 'To confirm'}\nQuantity: ${quantity}\nPrice: ${price}`
  }
  const buildUrl = (payload = {}) => `https://wa.me/${siteConfig.whatsapp}?text=${encodeURIComponent(buildMessage(payload))}`
  return { buildMessage, buildUrl }
}
