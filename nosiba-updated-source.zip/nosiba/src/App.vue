<script setup>
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { RouterLink, RouterView, useRoute, useRouter } from 'vue-router'
import Offcanvas from 'bootstrap/js/dist/offcanvas'
import { useLanguage } from './composables/useLanguage.js'
import { useOrderCollection } from './composables/useOrderCollection.js'
import { useWhatsApp } from './composables/useWhatsApp.js'
import { siteConfig } from './data/siteConfig.js'

const { language, isArabic, setLanguage, t } = useLanguage()
const { items, count, updateQuantity, removeItem, clear } = useOrderCollection()
const { buildUrl } = useWhatsApp()
const route = useRoute()
const router = useRouter()
const scrolled = ref(false)
const menuOpen = ref(false)

const orderUrl = computed(() => buildUrl({ lang: language.value, items: items.value }))
let mobileMenuInstance
let revealObserver
let revealMutationObserver
const observedRevealElements = new WeakSet()
const navItems = computed(() => [
  { label: t('Home', 'الرئيسية'), to: '/' },
  { label: t('Shop', 'تسوقي'), to: '/shop' },
  { label: t('Collections', 'المجموعات'), to: '/collections' },
  { label: t('New arrivals', 'وصل حديثاً'), to: '/new-arrivals' },
  { label: t('About', 'عن نُسيبه'), to: '/about' },
  { label: t('Contact', 'تواصل معنا'), to: '/contact' },
])
const onScroll = () => { scrolled.value = window.scrollY > 20 }
const toggleMobileMenu = () => {
  const element = document.getElementById('mobileMenu')
  if (!element) return
  if (!mobileMenuInstance) {
    mobileMenuInstance = Offcanvas.getOrCreateInstance(element)
    element.addEventListener('shown.bs.offcanvas', () => { menuOpen.value = true })
    element.addEventListener('hidden.bs.offcanvas', () => { menuOpen.value = false })
  }
  if (menuOpen.value) {
    mobileMenuInstance.hide()
    return
  }
  menuOpen.value = true
  mobileMenuInstance.show()
}
const navigateMobile = async (to) => {
  await router.push(to)
  mobileMenuInstance?.hide()
}
const observeRevealNode = (node) => {
  if (!(node instanceof Element)) return
  const candidates = [
    ...(node.matches('.reveal') ? [node] : []),
    ...node.querySelectorAll('.reveal'),
  ]
  candidates.forEach((element) => {
    if (observedRevealElements.has(element)) return
    observedRevealElements.add(element)
    revealObserver.observe(element)
  })
}
watch(() => route.fullPath, () => mobileMenuInstance?.hide())
onMounted(() => {
  window.addEventListener('scroll', onScroll, { passive: true })
  if (!('IntersectionObserver' in window)) {
    document.querySelectorAll('.reveal').forEach((element) => element.classList.add('is-visible'))
    return
  }
  revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return
      entry.target.classList.add('is-visible')
      revealObserver.unobserve(entry.target)
    })
  }, { threshold: 0.08, rootMargin: '0px 0px -24px 0px' })
  observeRevealNode(document.documentElement)
  revealMutationObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => mutation.addedNodes.forEach(observeRevealNode))
  })
  revealMutationObserver.observe(document.querySelector('main'), { childList: true, subtree: true })
})
onUnmounted(() => {
  window.removeEventListener('scroll', onScroll)
  revealObserver?.disconnect()
  revealMutationObserver?.disconnect()
  mobileMenuInstance?.dispose()
})
</script>

<template>
  <div class="site-frame">
    <header class="site-header" :class="{ 'is-scrolled': scrolled, 'is-menu-open': menuOpen }">
      <div class="container-wide header-inner">
        <RouterLink to="/" class="brand-lockup" aria-label="Nosiba home">
          <span class="brand-seal">N</span>
          <span class="brand-name"><strong>Nosiba</strong><span>نُسيبه</span></span>
        </RouterLink>
        <nav class="nav-links desktop-nav" :aria-label="t('Primary navigation', 'التنقل الرئيسي')">
          <RouterLink v-for="item in navItems" :key="item.to" :to="item.to" class="nav-link">{{ item.label }}</RouterLink>
        </nav>
        <div class="header-actions">
          <button class="language-switch" type="button" :aria-label="t('Switch language', 'تغيير اللغة')" @click="setLanguage(language === 'en' ? 'ar' : 'en')">
            <span :class="{ 'is-active': language === 'en' }" @click.stop="setLanguage('en')">EN</span><span>/</span><span :class="{ 'is-active': language === 'ar' }" @click.stop="setLanguage('ar')">العربية</span>
          </button>
          <button class="icon-button position-relative" type="button" data-bs-toggle="offcanvas" data-bs-target="#orderDrawer" :aria-label="t('Open order collection', 'فتح الطلب')"><svg class="nav-order-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 8h12l1.2 13H4.8L6 8Zm3 0V6a3 3 0 0 1 6 0v2" /></svg><span v-if="count" class="order-count">{{ count }}</span></button>
          <button class="icon-button mobile-only" type="button" aria-label="Menu" aria-controls="mobileMenu" :aria-expanded="menuOpen" @click="toggleMobileMenu">☰</button>
        </div>
      </div>
    </header>

    <main><RouterView /></main>

    <a class="floating-whatsapp" :href="buildUrl({ lang: language })" target="_blank" rel="noopener" aria-label="WhatsApp">◌ <span>{{ t('WhatsApp us', 'واتساب') }}</span></a>

    <footer class="site-footer">
      <div class="container-wide">
        <div class="footer-grid">
          <div class="footer-col">
            <RouterLink to="/" class="brand-lockup mb-3"><span class="brand-seal">N</span><span class="brand-name"><strong>Nosiba</strong><span>نُسيبه</span></span></RouterLink>
            <p>{{ t('A quiet Egyptian abaya house, established in 2024.', 'دار مصرية للعبايات، تأسست عام ٢٠٢٤.') }}</p>
          </div>
          <div class="footer-col"><h3>{{ t('Explore', 'اكتشفي') }}</h3><RouterLink v-for="item in navItems.slice(0, 4)" :key="item.to" :to="item.to">{{ item.label }}</RouterLink></div>
          <div class="footer-col"><h3>{{ t('Visit', 'زورينا') }}</h3><p>{{ t('Warraq, Giza, Egypt', 'الوراق، الجيزة، مصر') }}</p><a :href="`tel:${siteConfig.phone}`">{{ siteConfig.phone }}</a><a :href="buildUrl({ lang: language })" target="_blank" rel="noopener">WhatsApp</a></div>
          <div class="footer-col"><h3>{{ t('Prototype note', 'ملاحظة النسخة التجريبية') }}</h3><p>{{ t(siteConfig.temporaryNotice.en, siteConfig.temporaryNotice.ar) }}</p></div>
        </div>
        <div class="footer-bottom"><span>© {{ new Date().getFullYear() }} Nosiba / نُسيبه</span><span>{{ t('Made with intention in Egypt.', 'صُنع بعناية في مصر.') }}</span></div>
      </div>
    </footer>

    <Teleport to="body">
      <div id="mobileMenu" class="offcanvas offcanvas-end" tabindex="-1" aria-labelledby="mobileMenuLabel">
        <div class="offcanvas-header"><h2 id="mobileMenuLabel" class="serif h3 mb-0">{{ t('Menu', 'القائمة') }}</h2><button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button></div>
        <div class="offcanvas-body d-flex flex-column gap-3">
          <a v-for="item in navItems" :key="item.to" :href="router.resolve(item.to).href" class="h4 serif" @click.prevent="navigateMobile(item.to)">{{ item.label }}</a>
          <div class="mt-auto notice-card">{{ t(siteConfig.temporaryNotice.en, siteConfig.temporaryNotice.ar) }}</div>
        </div>
      </div>
    </Teleport>

    <div id="orderDrawer" class="offcanvas offcanvas-end order-drawer" tabindex="-1" aria-labelledby="orderDrawerLabel">
      <div class="offcanvas-header"><h2 id="orderDrawerLabel" class="serif h3 mb-0">{{ t('Your order', 'طلبك') }}</h2><button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button></div>
      <div class="offcanvas-body">
        <div v-if="!items.length" class="empty-state"><h2>{{ t('Nothing here yet.', 'لا توجد قطع بعد.') }}</h2><p>{{ t('Add a piece and send your selection to Nosiba on WhatsApp.', 'أضيفي قطعة وأرسلي اختيارك إلى نُسيبه عبر واتساب.') }}</p><RouterLink to="/shop" class="btn btn-outline-nosiba" data-bs-dismiss="offcanvas">{{ t('Explore the collection', 'اكتشفي المجموعة') }}</RouterLink></div>
        <template v-else>
          <div v-for="(item, index) in items" :key="`${item.product.id}-${index}`" class="order-item"><img :src="item.product.images[0]" :alt="item.product.name" /><div><h4>{{ isArabic ? item.product.nameAr : item.product.name }}</h4><p>{{ item.size }} · {{ item.color }}</p><div class="quantity-row mb-0"><button type="button" @click="updateQuantity(index, item.quantity - 1)">−</button><input :value="item.quantity" readonly aria-label="Quantity" /><button type="button" @click="updateQuantity(index, item.quantity + 1)">+</button></div></div><button class="btn btn-link text-muted p-0" type="button" @click="removeItem(index)" aria-label="Remove">×</button></div>
          <a class="btn btn-nosiba w-100 mt-4" :href="orderUrl" target="_blank" rel="noopener" @click="clear">{{ t('Send order via WhatsApp', 'إرسال الطلب عبر واتساب') }}</a>
          <p class="muted small mt-3">{{ t('Prices and details are confirmed manually because this is a prototype catalog.', 'يتم تأكيد الأسعار والتفاصيل يدوياً لأن هذه نسخة تجريبية.') }}</p>
        </template>
      </div>
    </div>
  </div>
</template>
