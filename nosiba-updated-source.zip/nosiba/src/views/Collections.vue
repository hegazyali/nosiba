<script setup>
import { onMounted } from 'vue'
import { useLanguage } from '../composables/useLanguage.js'
import { categories } from '../data/categories.js'
import { useProducts } from '../composables/useProducts.js'
import CategoryRail from '../components/CategoryRail.vue'
import ProductGrid from '../components/ProductGrid.vue'
const { t } = useLanguage(); const { products } = useProducts()
onMounted(() => { document.title = 'Nosiba — Collections' })
</script>
<template>
  <div><section class="page-hero"><div class="container-wide"><span class="section-eyebrow">{{ t('Find your line', 'اختاري خطك') }}</span><h1 class="mt-3">{{ t('Collections.', 'المجموعات.') }}</h1><p>{{ t('Temporary groupings give the prototype a sense of rhythm. These will be regenerated from the real Nosiba assortment.', 'تمنح التجميعات المؤقتة النسخة التجريبية إيقاعاً واضحاً. وسيتم توليدها من تشكيلة نُسيبه الحقيقية.') }}</p></div></section><section class="section-pad pb-0"><div class="container-wide"><CategoryRail :categories="categories" /></div></section><section class="section-pad"><div class="container-wide"><div class="section-heading"><div><span class="section-eyebrow">{{ t('Everyday studies', 'دراسات يومية') }}</span><h2 class="mt-3">{{ t('Pieces in progress.', 'قطع قيد التشكيل.') }}</h2></div></div><ProductGrid :products="products" /></div></section></div>
</template>
