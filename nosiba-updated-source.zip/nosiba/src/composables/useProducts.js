import { computed, ref } from 'vue'
import { getProductOptions, products } from '../data/products.js'

export const useProducts = () => {
  const category = ref('all')
  const color = ref('all')
  const size = ref('all')
  const availability = ref('all')
  const sort = ref('featured')
  const priceCap = ref('all')

  const categories = computed(() => [...new Set(products.map((product) => product.category))])
  const colors = computed(() => [...new Set(products.flatMap((product) => getProductOptions(product, 'colors')))])
  const sizes = computed(() => [...new Set(products.flatMap((product) => getProductOptions(product, 'sizes')))])

  const filteredProducts = computed(() => {
    const output = products.filter((product) => {
      const productColors = getProductOptions(product, 'colors')
      const productSizes = getProductOptions(product, 'sizes')
      const price = product.price
      return (category.value === 'all' || product.category === category.value) &&
        (color.value === 'all' || productColors.includes(color.value)) &&
        (size.value === 'all' || productSizes.includes(size.value)) &&
        (availability.value === 'all' || (availability.value === 'available' ? product.available : !product.available)) &&
        (priceCap.value === 'all' || price === null || price === undefined || price <= Number(priceCap.value))
    })
    return [...output].sort((a, b) => {
      if (sort.value === 'price-low') return (a.price ?? 0) - (b.price ?? 0)
      if (sort.value === 'price-high') return (b.price ?? 0) - (a.price ?? 0)
      if (sort.value === 'newest') return Number(b.newArrival) - Number(a.newArrival)
      return Number(b.featured) - Number(a.featured)
    })
  })

  const resetFilters = () => {
    category.value = 'all'
    color.value = 'all'
    size.value = 'all'
    availability.value = 'all'
    sort.value = 'featured'
    priceCap.value = 'all'
  }

  return { products, category, color, size, availability, sort, priceCap, categories, colors, sizes, filteredProducts, resetFilters }
}
