<script setup>
import { computed, onMounted } from 'vue'
import { RouterLink, useRoute } from 'vue-router'
import { useLanguage } from '../composables/useLanguage.js'
import { products, formatPrice } from '../data/products.js'
import ProductGallery from '../components/ProductGallery.vue'
import WhatsAppOrderPanel from '../components/WhatsAppOrderPanel.vue'
import PaymentMethods from '../components/PaymentMethods.vue'
const route = useRoute(); const { t, isArabic } = useLanguage(); const product = computed(() => products.find((item) => item.slug === route.params.slug))
onMounted(() => { document.title = product.value ? `${product.value.name} — Nosiba` : 'Nosiba — Product' })
</script>
<template>
  <div v-if="product" class="product-detail"><div class="container-wide"><div class="breadcrumbs"><RouterLink to="/">{{ t('Home', 'الرئيسية') }}</RouterLink> <span aria-hidden="true">/</span> <RouterLink to="/shop">{{ t('Shop', 'تسوقي') }}</RouterLink> <span aria-hidden="true">/</span> <span>{{ isArabic ? product.nameAr : product.name }}</span></div><div class="product-detail-grid"><ProductGallery :product="product" /><div class="detail-info"><span class="detail-kicker">{{ isArabic ? product.categoryAr : product.category }}</span><h1>{{ isArabic ? product.nameAr : product.name }}</h1><div class="arabic-name">{{ isArabic ? product.name : product.nameAr }}</div><p class="detail-description mt-4">{{ isArabic ? product.descriptionAr : product.description }}</p><div class="notice-card my-4">{{ t(product.temporaryLabel.en, product.temporaryLabel.ar) }}</div><WhatsAppOrderPanel :product="product" /></div></div></div><PaymentMethods /></div>
  <div v-else class="section-pad"><div class="container-wide"><div class="empty-state"><h2>{{ t('Piece not found.', 'لم نجد هذه القطعة.') }}</h2><p>{{ t('Return to the catalog to continue exploring.', 'عودي إلى الكتالوج لمواصلة الاستكشاف.') }}</p><RouterLink to="/shop" class="btn btn-nosiba">{{ t('Back to shop', 'العودة للتسوق') }}</RouterLink></div></div></div>
</template>
