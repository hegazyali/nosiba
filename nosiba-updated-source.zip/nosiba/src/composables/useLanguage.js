import { computed, ref, watch } from 'vue'

const stored = typeof window !== 'undefined' ? window.localStorage.getItem('nosiba-language') : null
const language = ref(stored === 'ar' ? 'ar' : 'en')

export const useLanguage = () => {
  const isArabic = computed(() => language.value === 'ar')
  const dir = computed(() => isArabic.value ? 'rtl' : 'ltr')
  const t = (en, ar) => isArabic.value ? ar : en
  const setLanguage = (next) => { language.value = next === 'ar' ? 'ar' : 'en' }
  watch(language, (next) => {
    if (typeof document !== 'undefined') {
      document.documentElement.lang = next
      document.documentElement.dir = next === 'ar' ? 'rtl' : 'ltr'
      document.body.classList.toggle('is-rtl', next === 'ar')
      window.localStorage.setItem('nosiba-language', next)
    }
  }, { immediate: true })
  return { language, isArabic, dir, t, setLanguage }
}
