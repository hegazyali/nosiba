export const siteConfig = {
  brandName: 'Nosiba', brandNameAr: 'نُسيبه',
  tagline: 'Quiet form, considered detail.', taglineAr: 'خط هادئ، وتفاصيل مدروسة.',
  announcement: 'Prototype preview · real Nosiba collection arriving soon', announcementAr: 'نسخة تجريبية · مجموعة نُسيبه الحقيقية قريباً',
  whatsapp: '201090955466', phone: '01090955466',
  address: { country: 'Egypt', city: 'Giza', area: 'Warraq', street: 'Army Street' },
  addressAr: { country: 'مصر', city: 'الجيزة', area: 'الوراق', street: 'شارع الجيش' },
  workingDays: 'Saturday – Friday', workingDaysAr: 'من السبت إلى الجمعة',
  dayOff: 'Sunday', dayOffAr: 'الأحد',
  shipping: 'All Egypt', shippingAr: 'كل أنحاء مصر',
  established: '2024', specialization: 'Abayas', specializationAr: 'عبايات',
  instapayUrl: 'https://ipn.eg/S/alihegazy10/instapay/5qMFalYoy',
  temporaryNotice: { en: 'Temporary imagery and editable product records are used until real Nosiba assets arrive.', ar: 'نستخدم صوراً مؤقتة وسجلات قابلة للتعديل حتى وصول أصول نُسيبه الحقيقية.' },
}
