<script setup>
import { computed, onMounted, ref } from 'vue'
import { RouterLink } from 'vue-router'
import { useLanguage } from '../composables/useLanguage.js'
import { useProducts } from '../composables/useProducts.js'
import { categories } from '../data/categories.js'
import ProductGrid from '../components/ProductGrid.vue'
import CategoryRail from '../components/CategoryRail.vue'
import StorySection from '../components/StorySection.vue'
import PaymentMethods from '../components/PaymentMethods.vue'
import ContactSection from '../components/ContactSection.vue'
import { siteConfig } from '../data/siteConfig.js'
const { t, isArabic } = useLanguage()
const { products } = useProducts()
const activeTab = ref('featured')
const tabProducts = computed(() => activeTab.value === 'featured' ? products.filter((item) => item.featured) : activeTab.value === 'new' ? products.filter((item) => item.newArrival) : products)
onMounted(() => { document.title = 'Nosiba / نُسيبه — Premium Egyptian Abayas' })
</script>

<template>
  <div>
    <section class="hero"><div class="container-wide hero-grid"><div class="hero-copy reveal"><div class="section-eyebrow hero-kicker">{{ t('Nosiba / 2024', 'نُسيبه / ٢٠٢٤') }}</div><h1 class="display-title hero-title" v-html="t('Quiet form, <em>considered</em> detail.', 'خط هادئ، <em>وتفاصيل</em> مدروسة.')"></h1><p class="hero-subtitle">{{ t('A temporary editorial preview for a premium Egyptian abaya house. The real Nosiba collection will replace every placeholder when it is ready.', 'نسخة تحريرية مؤقتة لدار مصرية للعبايات. ستستبدل مجموعة نُسيبه الحقيقية كل عنصر مؤقت عند جاهزيتها.') }}</p><div class="hero-ctas"><RouterLink to="/shop" class="btn btn-nosiba">{{ t('Shop the prototype', 'تصفحي النسخة التجريبية') }} ↗</RouterLink><a class="btn btn-outline-nosiba" href="https://wa.me/201090955466" target="_blank" rel="noopener">{{ t('Ask on WhatsApp', 'اسألي عبر واتساب') }}</a></div></div><div class="hero-media reveal"><img :src="products[0].images[0]" alt="Temporary editorial abaya image" fetchpriority="high" /><div class="hero-note">{{ t(siteConfig.temporaryNotice.en, siteConfig.temporaryNotice.ar) }}</div></div></div><span class="hero-scroll">{{ t('Scroll to discover', 'اكتشفي المزيد') }}</span></section>

    <section class="section-pad pb-0"><div class="container-wide"><div class="section-heading reveal"><div><span class="section-eyebrow">{{ t('The edit', 'الاختيارات') }}</span><h2 class="mt-3">{{ t('Begin with a mood.', 'ابدئي بإحساس.') }}</h2></div><p>{{ t('A few placeholder directions are here to shape the first Nosiba experience. The real classification will follow the real products.', 'بعض الاختيارات المؤقتة هنا لتشكيل تجربة نُسيبه الأولى. التصنيف الحقيقي سيتبع المنتجات الحقيقية.') }}</p></div><CategoryRail :categories="categories" /></div></section>

    <section class="section-pad"><div class="container-wide"><div class="section-heading reveal"><div><span class="section-eyebrow">{{ t('Discover', 'اكتشفي') }}</span><h2 class="mt-3">{{ t('A softer kind of statement.', 'حضور أكثر هدوءاً.') }}</h2></div><RouterLink to="/shop" class="btn btn-outline-nosiba">{{ t('View all pieces', 'كل القطع') }} ↗</RouterLink></div><div class="product-tabs"><button class="tab-button" :class="{ 'is-active': activeTab === 'featured' }" type="button" @click="activeTab = 'featured'">{{ t('Featured', 'مختارات') }}</button><button class="tab-button" :class="{ 'is-active': activeTab === 'new' }" type="button" @click="activeTab = 'new'">{{ t('New arrivals', 'وصل حديثاً') }}</button><button class="tab-button" :class="{ 'is-active': activeTab === 'all' }" type="button" @click="activeTab = 'all'">{{ t('All', 'الكل') }}</button></div><ProductGrid :products="tabProducts" /></div></section>

    <StorySection /><PaymentMethods /><ContactSection />
  </div>
</template>
