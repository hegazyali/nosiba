export default {
  logoUrl: "https://files.manuscdn.com/search-media/310419663030247904/xahum5JsoOFSJAuwbMIJCb/vQr9RGY6i4FmHJRNVMdCga.jpg"
}
