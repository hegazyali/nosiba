# Deploy Nosiba to Vercel

## Recommended: authorize Manus to deploy

1. Open Manus **Settings**.
2. Go to **Integrations / Connectors**.
3. Find **Vercel** and click **Connect** or **Enable**.
4. Authorize access to the Vercel account/team and the projects you want Manus to manage.
5. Return to the conversation and reply `ready`.

Do not paste a Vercel token, password, or secret into chat. Use the secure connector authorization flow.

## Manual deployment from this folder

Requirements: Node.js 18+ and a Vercel account.

```bash
npm install
npm run build
npx vercel --prod
```

The Vite build output is `dist/`. The temporary editorial images are bundled in `public/assets/`, so they work on Vercel without Manus storage URLs. Replace those files and the references in `src/data/products.js` when the real Nosiba photos are ready.
