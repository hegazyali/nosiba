<script setup>
import { computed, onMounted } from 'vue'
import { useLanguage } from '../composables/useLanguage.js'
import { useProducts } from '../composables/useProducts.js'
import ProductGrid from '../components/ProductGrid.vue'
const { t } = useLanguage(); const { products } = useProducts(); const arrivals = computed(() => products.filter((product) => product.newArrival))
onMounted(() => { document.title = 'Nosiba — New Arrivals' })
</script>
<template>
  <div><section class="page-hero"><div class="container-wide"><span class="section-eyebrow">{{ t('Just in', 'وصل حديثاً') }}</span><h1 class="mt-3">{{ t('New arrivals.', 'وصل حديثاً.') }}</h1><p>{{ t('A temporary arrival view to preview the discovery flow. Real launch status will come from the verified product data.', 'عرض وصول مؤقت لمعاينة تجربة الاكتشاف. ستأتي حالة الإطلاق الحقيقية من بيانات المنتجات المؤكدة.') }}</p></div></section><section class="section-pad"><div class="container-wide"><ProductGrid v-if="arrivals.length" :products="arrivals" /><div v-else class="empty-state"><h2>{{ t('Arrivals are on their way.', 'القطع الجديدة قادمة.') }}</h2></div></div></section></div>
</template>
