<script setup>
import { onMounted } from 'vue'
import { RouterLink } from 'vue-router'
import { useLanguage } from '../composables/useLanguage.js'
const { t } = useLanguage(); onMounted(() => { document.title = 'Nosiba — Not found' })
</script>
<template><section class="section-pad"><div class="container-wide"><div class="empty-state"><span class="section-eyebrow justify-content-center">404</span><h2 class="mt-3">{{ t('This page took a quiet turn.', 'هذه الصفحة أخذت منعطفاً هادئاً.') }}</h2><p>{{ t('Let us take you back to the collection.', 'لنعد بك إلى المجموعة.') }}</p><RouterLink to="/" class="btn btn-nosiba">{{ t('Back home', 'العودة للرئيسية') }}</RouterLink></div></div></section></template>
