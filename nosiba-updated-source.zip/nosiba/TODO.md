# Nosiba / نُسيبه — Implementation Todo

- Build a runnable Vue.js + Bootstrap 5 website with custom Nosiba styling, responsive layouts, and an original replaceable wordmark/monogram.
- Use centralized temporary product and site data; clearly label all staged imagery and placeholder product facts as temporary until real Nosiba data is supplied.
- Implement English LTR and Arabic RTL with persistent language switching across navigation, product cards, product details, filters, forms, gallery, breadcrumbs, mobile menu, footer, and metadata.
- Implement routes for home, shop, collections, new arrivals, about, contact, product details, and not-found, and keep `public/manus-routes.json` synchronized.
- Implement premium editorial homepage sections, featured categories, product discovery, product cards, subtle reveal/hover interactions, and responsive navigation with mobile offcanvas behavior.
- Implement shop search across English/Arabic product names and category, category/price/size/color/availability filters, sorting, empty states, and mobile filter controls.
- Implement `/products/:slug` detail pages with responsive gallery, optional video support, size/color/quantity selection, localized product metadata, availability, and WhatsApp ordering.
- Implement a WhatsApp order helper with `+201090955466` and bilingual messages containing product, size, color, quantity, and price; include lightweight cart/order collection with one combined WhatsApp message and no fake payment checkout.
- Display the supplied InstaPay link and Vodafone Cash number as manually handled payment information, and show All Egypt shipping coverage without inventing delivery cost or time.
- Implement factual About and factory Contact content using only the supplied Nosiba business facts; do not add fake reviews, ratings, customer counts, certifications, or unsupported claims.
- Add accessibility, lazy loading, reduced-motion support, visible focus states, semantic HTML, alt text, SEO metadata, and responsive handling from 320px through 1920px+.
- Run diagnostics, build, validate routes and key flows, inspect representative desktop/mobile previews, correct confirmed issues, and checkpoint the completed project.
