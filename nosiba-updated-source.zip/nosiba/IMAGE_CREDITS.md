# Image credits

These editorial photos were selected from free-stock search results and are bundled locally as optimized WebP files rather than hotlinked. The storefront is currently a prototype with sample/editorial photos, not verified Nosiba inventory imagery. Confirm license and attribution requirements with each source page before commercial launch.

- `public/assets/look-01.webp` — “Elegant Woman in Embroidered Beige Abaya”, Pexels result.
- `public/assets/look-02.webp` — “Elegant Portrait of Woman in Beige Hijab Fashion”, Pexels result.
- `public/assets/look-03.webp` — “Abayas Pictures”, Unsplash result.
- `public/assets/look-04.webp` — “Elegant Women in Modest Fashion Abaya”, Pexels result.
- `public/assets/look-05.webp` — “A woman in a black abaya with intricate embellishments sits”, Unsplash result.

Replace all sample editorial images with the brand’s own product photography before launch.
