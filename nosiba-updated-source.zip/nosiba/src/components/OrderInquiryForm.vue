<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { useLanguage } from '../composables/useLanguage.js'
import { getProductOptions, products } from '../data/products.js'
import { siteConfig } from '../data/siteConfig.js'

const { isArabic, t } = useLanguage()
const form = reactive({
  fullName: '',
  phone: '',
  productId: '',
  size: '',
  color: '',
  quantity: 1,
  notes: '',
})
const errors = reactive({})
const submitted = ref(false)
const whatsAppUrl = ref('')

const selectedProduct = computed(() => products.find((product) => product.id === form.productId) || null)
const sizes = computed(() => getProductOptions(selectedProduct.value, 'sizes'))
const colors = computed(() => getProductOptions(selectedProduct.value, 'colors'))
const hasErrors = computed(() => Object.keys(errors).length > 0)

const watchProduct = () => {
  form.size = ''
  form.color = ''
  delete errors.productId
  delete errors.size
  delete errors.color
  submitted.value = false
  whatsAppUrl.value = ''
}
watch(() => form.productId, watchProduct)

const clearError = (field) => {
  delete errors[field]
  submitted.value = false
  whatsAppUrl.value = ''
}

const errorText = (code) => {
  const messages = {
    name: t('Enter your full name.', 'يرجى إدخال الاسم الكامل.'),
    phone: t('Enter a valid phone number (7–15 digits).', 'يرجى إدخال رقم هاتف صحيح (من ٧ إلى ١٥ رقماً).'),
    product: t('Select a product.', 'يرجى اختيار المنتج.'),
    size: t('Select an available size.', 'يرجى اختيار مقاس متاح.'),
    color: t('Select an available color.', 'يرجى اختيار لون متاح.'),
    quantity: t('Enter a whole quantity from 1 to 99.', 'يرجى إدخال كمية صحيحة من ١ إلى ٩٩.'),
  }
  return messages[code] || ''
}

const validate = () => {
  Object.keys(errors).forEach((key) => delete errors[key])
  if (!form.fullName.trim()) errors.fullName = 'name'

  const phone = form.phone.trim()
  const digits = phone.replace(/\D/g, '')
  if (!phone || !/^[+()\d\s.-]+$/.test(phone) || digits.length < 7 || digits.length > 15) errors.phone = 'phone'

  if (!selectedProduct.value) errors.productId = 'product'
  if (sizes.value.length && !form.size) errors.size = 'size'
  if (colors.value.length && !form.color) errors.color = 'color'

  const quantity = Number(form.quantity)
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 99) errors.quantity = 'quantity'
  return !hasErrors.value
}

const variantMessage = (value, options) => {
  if (options.length) return value
  if (value.trim()) {
    return isArabic.value
      ? `المطلوب: ${value.trim()} (يرجى تأكيد التوفر)`
      : `Requested: ${value.trim()} (please confirm availability)`
  }
  return t('To be confirmed with Nosiba', 'يُرجى التأكيد مع نُسيبه')
}

const submitOrder = () => {
  submitted.value = false
  whatsAppUrl.value = ''
  if (!validate()) return

  const productName = isArabic.value ? selectedProduct.value.nameAr : selectedProduct.value.name
  const size = variantMessage(form.size, sizes.value)
  const color = variantMessage(form.color, colors.value)
  const notes = form.notes.trim() || t('No additional notes', 'لا توجد ملاحظات إضافية')
  const message = isArabic.value
    ? `مرحباً نُسيبه،\n\nأرغب في طلب المنتج التالي:\n\nالاسم: ${form.fullName.trim()}\nرقم الهاتف: ${form.phone.trim()}\n\nالمنتج: ${productName}\nالمقاس: ${size}\nاللون: ${color}\nالكمية: ${Number(form.quantity)}\n\nملاحظات إضافية:\n${notes}\n\nيرجى تأكيد التوفر والسعر وتفاصيل التوصيل.`
    : `Hello Nosiba,\n\nI would like to place an order.\n\nName: ${form.fullName.trim()}\nPhone: ${form.phone.trim()}\n\nProduct: ${productName}\nSize: ${size}\nColor: ${color}\nQuantity: ${Number(form.quantity)}\n\nAdditional Notes:\n${notes}\n\nPlease confirm availability, price, and delivery details.`

  const number = siteConfig.whatsapp.replace(/\D/g, '')
  whatsAppUrl.value = `https://wa.me/${number}?text=${encodeURIComponent(message)}`
  submitted.value = true
  window.open(whatsAppUrl.value, '_blank', 'noopener,noreferrer')
}
</script>

<template>
  <section class="section-pad pt-0 order-inquiry-section">
    <div class="container-wide">
      <div class="section-heading">
        <div>
          <span class="section-eyebrow">{{ t('Order / Inquiry', 'طلب / استفسار') }}</span>
          <h2 class="mt-3">{{ t('Tell us what you have in mind.', 'أخبرينا بما تبحثين عنه.') }}</h2>
        </div>
        <p>{{ t('Share your details and we will prepare a message to Nosiba in WhatsApp. No payment is taken on this page.', 'أدخلي بياناتك لنجهّز رسالة إلى نُسيبه عبر واتساب. لا يتم الدفع من خلال هذه الصفحة.') }}</p>
      </div>

      <div class="order-form-shell">
        <p class="order-required-note"><span aria-hidden="true">*</span> {{ t('Required fields', 'حقول مطلوبة') }}</p>
        <p v-if="hasErrors" class="order-form-summary" role="alert" tabindex="-1">
          {{ t('Please review the highlighted fields.', 'يرجى مراجعة الحقول الموضحة.') }}
        </p>

        <form class="order-form-grid" novalidate @submit.prevent="submitOrder">
          <div class="order-form-field">
            <label for="order-product">{{ t('Product', 'المنتج') }} <span class="order-required" aria-hidden="true">*</span></label>
            <select id="order-product" v-model="form.productId" class="order-form-control" required :aria-invalid="Boolean(errors.productId)" aria-describedby="order-product-error" @change="clearError('productId')">
              <option value="" disabled>{{ t('Select a product', 'اختاري المنتج') }}</option>
              <option v-for="product in products" :key="product.id" :value="product.id">
                {{ isArabic ? product.nameAr : product.name }}
              </option>
            </select>
            <p v-if="errors.productId" id="order-product-error" class="order-form-error">{{ errorText(errors.productId) }}</p>
          </div>

          <div class="order-form-field">
            <label for="order-quantity">{{ t('Quantity', 'الكمية') }} <span class="order-required" aria-hidden="true">*</span></label>
            <div class="order-quantity-control" :aria-invalid="Boolean(errors.quantity)">
              <button type="button" :aria-label="t('Decrease quantity', 'تقليل الكمية')" @click="form.quantity = Math.max(1, Number(form.quantity || 1) - 1); clearError('quantity')">−</button>
              <input id="order-quantity" v-model.number="form.quantity" type="number" min="1" max="99" step="1" inputmode="numeric" required :aria-invalid="Boolean(errors.quantity)" aria-describedby="order-quantity-error" @input="clearError('quantity')" />
              <button type="button" :aria-label="t('Increase quantity', 'زيادة الكمية')" @click="form.quantity = Math.min(99, Number(form.quantity || 1) + 1); clearError('quantity')">+</button>
            </div>
            <p v-if="errors.quantity" id="order-quantity-error" class="order-form-error">{{ errorText(errors.quantity) }}</p>
          </div>

          <div class="order-form-field">
            <label for="order-size">{{ t('Size', 'المقاس') }}<span v-if="sizes.length" class="order-required" aria-hidden="true"> *</span><span v-else class="order-field-optional">{{ t('Optional', 'اختياري') }}</span></label>
            <select v-if="sizes.length" id="order-size" v-model="form.size" class="order-form-control" required :aria-invalid="Boolean(errors.size)" aria-describedby="order-size-error" @change="clearError('size')">
              <option value="" disabled>{{ t('Select a size', 'اختاري المقاس') }}</option>
              <option v-for="size in sizes" :key="size" :value="size">{{ size }}</option>
            </select>
            <input v-else id="order-size" v-model="form.size" class="order-form-control" type="text" :disabled="!selectedProduct" :placeholder="selectedProduct ? t('If you have a preference (optional)', 'إذا كان لديكِ مقاس مفضل (اختياري)') : t('Select a product first', 'اختاري المنتج أولاً')" aria-describedby="order-size-hint" @input="clearError('size')" />
            <p v-if="errors.size" id="order-size-error" class="order-form-error">{{ errorText(errors.size) }}</p>
            <p v-else-if="!sizes.length" id="order-size-hint" class="order-form-hint">{{ selectedProduct ? t('No verified sizes are listed; availability will be confirmed on WhatsApp.', 'لا توجد مقاسات مؤكدة في البيانات؛ سيتم تأكيد التوفر عبر واتساب.') : t('Choose a product to add an optional size preference.', 'اختاري المنتج لإضافة مقاس مفضل اختياري.') }}</p>
          </div>

          <div class="order-form-field">
            <label for="order-color">{{ t('Color', 'اللون') }}<span v-if="colors.length" class="order-required" aria-hidden="true"> *</span><span v-else class="order-field-optional">{{ t('Optional', 'اختياري') }}</span></label>
            <select v-if="colors.length" id="order-color" v-model="form.color" class="order-form-control" required :aria-invalid="Boolean(errors.color)" aria-describedby="order-color-error" @change="clearError('color')">
              <option value="" disabled>{{ t('Select a color', 'اختاري اللون') }}</option>
              <option v-for="color in colors" :key="color" :value="color">{{ color }}</option>
            </select>
            <input v-else id="order-color" v-model="form.color" class="order-form-control" type="text" :disabled="!selectedProduct" :placeholder="selectedProduct ? t('If you have a preference (optional)', 'إذا كان لديكِ لون مفضل (اختياري)') : t('Select a product first', 'اختاري المنتج أولاً')" aria-describedby="order-color-hint" @input="clearError('color')" />
            <p v-if="errors.color" id="order-color-error" class="order-form-error">{{ errorText(errors.color) }}</p>
            <p v-else-if="!colors.length" id="order-color-hint" class="order-form-hint">{{ selectedProduct ? t('No verified colors are listed; availability will be confirmed on WhatsApp.', 'لا توجد ألوان مؤكدة في البيانات؛ سيتم تأكيد التوفر عبر واتساب.') : t('Choose a product to add an optional color preference.', 'اختاري المنتج لإضافة لون مفضل اختياري.') }}</p>
          </div>

          <div class="order-form-field">
            <label for="order-name">{{ t('Full Name', 'الاسم الكامل') }} <span class="order-required" aria-hidden="true">*</span></label>
            <input id="order-name" v-model="form.fullName" class="order-form-control" type="text" autocomplete="name" maxlength="120" required :aria-invalid="Boolean(errors.fullName)" aria-describedby="order-name-error" @input="clearError('fullName')" />
            <p v-if="errors.fullName" id="order-name-error" class="order-form-error">{{ errorText(errors.fullName) }}</p>
          </div>

          <div class="order-form-field">
            <label for="order-phone">{{ t('Phone Number', 'رقم الهاتف') }} <span class="order-required" aria-hidden="true">*</span></label>
            <input id="order-phone" v-model="form.phone" class="order-form-control" type="tel" inputmode="tel" autocomplete="tel" dir="ltr" maxlength="24" required :aria-invalid="Boolean(errors.phone)" aria-describedby="order-phone-error" @input="clearError('phone')" />
            <p v-if="errors.phone" id="order-phone-error" class="order-form-error">{{ errorText(errors.phone) }}</p>
          </div>

          <div class="order-form-field order-form-field-wide">
            <label for="order-notes">{{ t('Additional Notes', 'ملاحظات إضافية') }} <span class="order-field-optional">{{ t('Optional', 'اختياري') }}</span></label>
            <textarea id="order-notes" v-model="form.notes" class="order-form-control order-form-textarea" rows="4" maxlength="1000" :placeholder="t('Anything else Nosiba should know?', 'هل هناك تفاصيل أخرى تودين إخبار نُسيبه بها؟')" @input="clearError('notes')"></textarea>
          </div>

          <div class="order-form-field order-form-field-wide order-form-actions">
            <button class="btn btn-nosiba order-form-submit" type="submit">{{ t('Submit Order', 'إرسال الطلب') }} <span aria-hidden="true">↗</span></button>
            <p class="order-form-disclaimer">{{ t('This prepares a WhatsApp message only. Review and send it in WhatsApp; your order is not confirmed until you send the message.', 'سيتم تجهيز رسالة واتساب فقط. راجعيها وأرسليها عبر واتساب؛ لا يتأكد الطلب إلا بعد إرسال الرسالة.') }}</p>
          </div>
        </form>

        <div v-if="submitted" class="order-form-result" role="status">
          <p>{{ t('Your message is ready in WhatsApp. Please review it and send it to submit your inquiry.', 'رسالتك جاهزة في واتساب. يرجى مراجعتها وإرسالها لتقديم طلبك.') }}</p>
          <a :href="whatsAppUrl" class="btn btn-outline-nosiba" target="_blank" rel="noopener noreferrer">{{ t('Open WhatsApp message', 'فتح رسالة واتساب') }}</a>
        </div>
      </div>
    </div>
  </section>
</template>
