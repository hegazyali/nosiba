import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Shop from '../views/Shop.vue'
import Collections from '../views/Collections.vue'
import NewArrivals from '../views/NewArrivals.vue'
import About from '../views/About.vue'
import Contact from '../views/Contact.vue'
import ProductDetails from '../views/ProductDetails.vue'
import NotFound from '../views/NotFound.vue'

export const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  scrollBehavior: (_to, _from, savedPosition) => savedPosition || ({ top: 0, behavior: 'instant' }),
  routes: [
    { path: '/', name: 'home', component: Home },
    { path: '/shop', name: 'shop', component: Shop },
    { path: '/collections', name: 'collections', component: Collections },
    { path: '/new-arrivals', name: 'new-arrivals', component: NewArrivals },
    { path: '/about', name: 'about', component: About },
    { path: '/contact', name: 'contact', component: Contact },
    { path: '/products/:slug', name: 'product', component: ProductDetails },
    { path: '/:pathMatch(.*)*', name: 'not-found', component: NotFound },
  ],
})
