<script setup>
import { computed, ref, watch } from 'vue'
import { useLanguage } from '../composables/useLanguage.js'
import { useWhatsApp } from '../composables/useWhatsApp.js'
import { useOrderCollection } from '../composables/useOrderCollection.js'
import { formatPrice, getProductOptions } from '../data/products.js'

const props = defineProps({ product: { type: Object, required: true } })
const { language, isArabic, t } = useLanguage()
const { buildUrl } = useWhatsApp()
const { addItem } = useOrderCollection()
const sizes = computed(() => getProductOptions(props.product, 'sizes'))
const colors = computed(() => getProductOptions(props.product, 'colors'))
const selectedSize = ref(sizes.value[0] || '')
const selectedColor = ref(colors.value[0] || '')
const quantity = ref(1)
const orderUrl = computed(() => buildUrl({ product: props.product, size: selectedSize.value, color: selectedColor.value, quantity: quantity.value, lang: language.value }))
const addToOrder = () => addItem(props.product, selectedSize.value, selectedColor.value, quantity.value)

watch(sizes, (options) => { selectedSize.value = options[0] || '' })
watch(colors, (options) => { selectedColor.value = options[0] || '' })
</script>

<template>
  <div class="detail-options">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <span class="detail-kicker">{{ t('Editable prototype record', 'سجل تجريبي قابل للتعديل') }}</span>
      <span class="detail-price m-0">{{ formatPrice(product.price, isArabic ? 'ar' : 'en') }}</span>
    </div>
    <div class="availability-line" :class="{ 'is-unavailable': !product.available }">{{ product.available ? t('Available to discuss', 'متاح للمناقشة') : t('Currently unavailable', 'غير متاح حالياً') }}</div>

    <div class="option-label"><span>{{ t('Size', 'المقاس') }}</span><span>{{ selectedSize || t('To confirm', 'يُحدد لاحقاً') }}</span></div>
    <div v-if="sizes.length" class="option-row">
      <button v-for="size in sizes" :key="size" class="option-button" :class="{ 'is-active': selectedSize === size }" type="button" @click="selectedSize = size">{{ size }}</button>
    </div>
    <p v-else class="detail-variant-note">{{ t('No verified size options are listed; confirm availability on WhatsApp.', 'لا توجد مقاسات مؤكدة في البيانات؛ يرجى تأكيد التوفر عبر واتساب.') }}</p>

    <div class="option-label"><span>{{ t('Color', 'اللون') }}</span><span>{{ selectedColor || t('To confirm', 'يُحدد لاحقاً') }}</span></div>
    <div v-if="colors.length" class="option-row">
      <button v-for="color in colors" :key="color" class="option-button" :class="{ 'is-active': selectedColor === color }" type="button" @click="selectedColor = color">{{ color }}</button>
    </div>
    <p v-else class="detail-variant-note">{{ t('No verified color options are listed; confirm availability on WhatsApp.', 'لا توجد ألوان مؤكدة في البيانات؛ يرجى تأكيد التوفر عبر واتساب.') }}</p>

    <div class="option-label"><span>{{ t('Quantity', 'الكمية') }}</span><span>{{ quantity }}</span></div>
    <div class="quantity-row">
      <button type="button" :aria-label="t('Decrease quantity', 'تقليل الكمية')" @click="quantity = Math.max(1, quantity - 1)">−</button>
      <input v-model.number="quantity" type="number" min="1" aria-label="Quantity" />
      <button type="button" :aria-label="t('Increase quantity', 'زيادة الكمية')" @click="quantity += 1">+</button>
    </div>
    <div class="detail-actions">
      <a class="btn btn-nosiba" :href="orderUrl" target="_blank" rel="noopener">{{ t('Order on WhatsApp', 'اطلبي عبر واتساب') }}</a>
      <button class="btn btn-outline-nosiba" type="button" @click="addToOrder">{{ t('Add to order', 'أضيفي للطلب') }}</button>
    </div>
  </div>
</template>
