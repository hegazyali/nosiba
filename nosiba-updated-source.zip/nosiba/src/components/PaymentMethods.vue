<script setup>
import { siteConfig } from '../data/siteConfig.js'
import { useLanguage } from '../composables/useLanguage.js'
const { t } = useLanguage()
</script>
<template>
  <section class="payment-strip section-pad"><div class="container-wide payment-grid"><div><span class="section-eyebrow">{{ t('Order with ease', 'اطلبي بسهولة') }}</span><h2 class="mt-3">{{ t('Pay manually, with care.', 'دفع يدوي، بعناية.') }}</h2><p>{{ t('Payment is arranged after your WhatsApp order is confirmed.', 'يتم ترتيب الدفع بعد تأكيد طلبك عبر واتساب.') }}</p></div><div class="payment-card"><small>InstaPay</small><strong><a :href="siteConfig.instapayUrl" target="_blank" rel="noopener">{{ t('Pay via InstaPay ↗', 'الدفع عبر إنستا باي ↗') }}</a></strong><p>{{ t('Manual confirmation', 'تأكيد يدوي') }}</p></div><div class="payment-card"><small>Vodafone Cash</small><strong>{{ siteConfig.phone }}</strong><p>{{ t('Manual confirmation', 'تأكيد يدوي') }}</p></div></div></section>
</template>
