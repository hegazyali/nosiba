<script setup>
import ProductCard from './ProductCard.vue'
import { useLanguage } from '../composables/useLanguage.js'
defineProps({ products: { type: Array, default: () => [] } })
const { t } = useLanguage()
</script>
<template>
  <div v-if="products.length" class="product-grid"><ProductCard v-for="product in products" :key="product.id" :product="product" /></div>
  <div v-else class="empty-state"><h2>{{ t('Nothing found.', 'لم نجد شيئاً.') }}</h2><p>{{ t('Try a different edit or reset the filters.', 'جربي اختياراً مختلفاً أو أعيدي ضبط الفلاتر.') }}</p></div>
</template>
