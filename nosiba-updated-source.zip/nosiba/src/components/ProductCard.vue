<script setup>
import { RouterLink } from 'vue-router'
import { formatPrice } from '../data/products.js'
import { useLanguage } from '../composables/useLanguage.js'
const props = defineProps({ product: { type: Object, required: true } })
const { isArabic, t } = useLanguage()
</script>

<template>
  <article class="product-card reveal">
    <RouterLink :to="`/products/${product.slug}`" :aria-label="isArabic ? product.nameAr : product.name">
      <div class="product-image-wrap">
        <span v-if="product.isTemporary" class="product-badge">{{ t('Prototype', 'تجريبي') }}</span>
        <img class="primary" :src="product.images[0]" :alt="isArabic ? product.nameAr : product.name" loading="lazy" />
        <img v-if="product.images[1]" class="secondary" :src="product.images[1]" :alt="''" loading="lazy" aria-hidden="true" />
        <span class="product-hover-action">{{ t('View piece', 'عرض القطعة') }} <span aria-hidden="true">↗</span></span>
      </div>
    </RouterLink>
    <div class="product-info">
      <RouterLink :to="`/products/${product.slug}`"><h3 class="product-name">{{ isArabic ? product.nameAr : product.name }}</h3><p class="product-name-ar">{{ isArabic ? product.name : product.nameAr }}</p></RouterLink>
      <div class="product-meta"><span>{{ isArabic ? product.categoryAr : product.category }}</span><span class="product-price">{{ formatPrice(product.price, isArabic ? 'ar' : 'en') }}</span></div>
      <p v-if="product.isTemporary" class="temp-label">{{ t(product.temporaryLabel.en, product.temporaryLabel.ar) }}</p>
    </div>
  </article>
</template>
