<script setup>
import { onMounted } from 'vue'
import { useLanguage } from '../composables/useLanguage.js'
import { siteConfig } from '../data/siteConfig.js'
import ContactSection from '../components/ContactSection.vue'
import OrderInquiryForm from '../components/OrderInquiryForm.vue'
import PaymentMethods from '../components/PaymentMethods.vue'

const { t } = useLanguage()
onMounted(() => { document.title = 'Nosiba — Contact' })
</script>

<template>
  <div>
    <section class="page-hero">
      <div class="container-wide">
        <span class="section-eyebrow">{{ t('Keep in touch', 'تواصلي معنا') }}</span>
        <h1 class="mt-3">{{ t('Contact.', 'تواصل.') }}</h1>
        <p>{{ t('Questions about the prototype, future stock, or store/reseller conversations? Reach the factory directly.', 'لديك أسئلة عن النسخة التجريبية أو التشكيلة القادمة أو التعامل مع المتاجر؟ تواصلي مع المصنع مباشرةً.') }}</p>
      </div>
    </section>

    <section class="section-pad">
      <div class="container-wide contact-grid">
        <div>
          <span class="section-eyebrow">{{ t('Factory details', 'تفاصيل المصنع') }}</span>
          <h2 class="display-title mt-4">{{ t('A direct line to the makers.', 'خط مباشر إلى المصنع.') }}</h2>
        </div>
        <div>
          <div class="contact-card">
            <h3>{{ t('Address', 'العنوان') }}</h3>
            <p>{{ t('Egypt · Giza · Warraq · Army Street', 'مصر · الجيزة · الوراق · شارع الجيش') }}</p>
          </div>
          <div class="contact-card">
            <h3>{{ t('Working days', 'أيام العمل') }}</h3>
            <p>{{ t(`${siteConfig.workingDays} · Sunday: Closed`, `${siteConfig.workingDaysAr} · الأحد إجازة`) }}</p>
          </div>
          <div class="contact-card">
            <h3>{{ t('Phone / WhatsApp', 'الهاتف / واتساب') }}</h3>
            <p>{{ siteConfig.phone }}</p>
          </div>
          <div class="d-flex flex-wrap gap-2 mt-4">
            <a class="btn btn-nosiba" :href="`tel:${siteConfig.phone}`">{{ t('Call now', 'اتصلي الآن') }}</a>
            <a class="btn btn-outline-nosiba" :href="`https://wa.me/${siteConfig.whatsapp}`" target="_blank" rel="noopener">{{ t('Open WhatsApp', 'فتح واتساب') }}</a>
          </div>
        </div>
      </div>
    </section>

    <OrderInquiryForm />
    <ContactSection />
    <PaymentMethods />
  </div>
</template>
