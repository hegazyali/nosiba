const temporaryLabel = {
  en: 'Prototype item · replace before launch',
  ar: 'قطعة تجريبية · تُستبدل قبل الإطلاق',
}

const baseUrl = import.meta.env.BASE_URL.endsWith('/') ? import.meta.env.BASE_URL : `${import.meta.env.BASE_URL}/`
export const mediaAsset = (path) => `${baseUrl}${path.replace(/^\/+/, '')}`

export const products = [
  {
    id: 'proto-01', slug: 'quiet-line-01', name: 'Quiet Line / 01', nameAr: 'خط هادئ / ٠١',
    price: null, category: 'Editorial edits', categoryAr: 'اختيارات تحريرية',
    sizes: ['EDITABLE_SIZE'], colors: ['EDITABLE_COLOR'], available: true,
    featured: true, newArrival: true, isTemporary: true, temporaryLabel,
    description: 'Temporary product record for layout preview. Replace with verified product details when Nosiba data is ready.',
    descriptionAr: 'سجل منتج مؤقت لمعاينة التصميم. يُستبدل بتفاصيل المنتج المؤكدة عند جاهزية بيانات نُسيبه.',
    images: [mediaAsset('assets/look-01.webp'), mediaAsset('assets/look-02.webp')], videos: [],
  },
  {
    id: 'proto-02', slug: 'soft-structure-02', name: 'Soft Structure / 02', nameAr: 'هيكل ناعم / ٠٢',
    price: null, category: 'Editorial edits', categoryAr: 'اختيارات تحريرية',
    sizes: ['EDITABLE_SIZE'], colors: ['EDITABLE_COLOR'], available: true,
    featured: true, newArrival: true, isTemporary: true, temporaryLabel,
    description: 'Temporary product record for layout preview. Replace with verified product details when Nosiba data is ready.',
    descriptionAr: 'سجل منتج مؤقت لمعاينة التصميم. يُستبدل بتفاصيل المنتج المؤكدة عند جاهزية بيانات نُسيبه.',
    images: [mediaAsset('assets/look-02.webp'), mediaAsset('assets/look-03.webp')], videos: [],
  },
  {
    id: 'proto-03', slug: 'afterglow-03', name: 'Afterglow / 03', nameAr: 'وهج هادئ / ٠٣',
    price: null, category: 'Soft neutrals', categoryAr: 'درجات محايدة',
    sizes: ['EDITABLE_SIZE'], colors: ['EDITABLE_COLOR'], available: true,
    featured: true, newArrival: false, isTemporary: true, temporaryLabel,
    description: 'Temporary product record for layout preview. Replace with verified product details when Nosiba data is ready.',
    descriptionAr: 'سجل منتج مؤقت لمعاينة التصميم. يُستبدل بتفاصيل المنتج المؤكدة عند جاهزية بيانات نُسيبه.',
    images: [mediaAsset('assets/look-03.webp'), mediaAsset('assets/look-04.webp')], videos: [],
  },
  {
    id: 'proto-04', slug: 'shadow-fold-04', name: 'Shadow Fold / 04', nameAr: 'طية ظل / ٠٤',
    price: null, category: 'Dark forms', categoryAr: 'قصّات داكنة',
    sizes: ['EDITABLE_SIZE'], colors: ['EDITABLE_COLOR'], available: true,
    featured: false, newArrival: true, isTemporary: true, temporaryLabel,
    description: 'Temporary product record for layout preview. Replace with verified product details when Nosiba data is ready.',
    descriptionAr: 'سجل منتج مؤقت لمعاينة التصميم. يُستبدل بتفاصيل المنتج المؤكدة عند جاهزية بيانات نُسيبه.',
    images: [mediaAsset('assets/look-04.webp'), mediaAsset('assets/look-05.webp')], videos: [],
  },
  {
    id: 'proto-05', slug: 'moonlit-volume-05', name: 'Moonlit Volume / 05', nameAr: 'حجم قمري / ٠٥',
    price: null, category: 'Dark forms', categoryAr: 'قصّات داكنة',
    sizes: ['EDITABLE_SIZE'], colors: ['EDITABLE_COLOR'], available: true,
    featured: false, newArrival: false, isTemporary: true, temporaryLabel,
    description: 'Temporary product record for layout preview. Replace with verified product details when Nosiba data is ready.',
    descriptionAr: 'سجل منتج مؤقت لمعاينة التصميم. يُستبدل بتفاصيل المنتج المؤكدة عند جاهزية بيانات نُسيبه.',
    images: [mediaAsset('assets/look-05.webp'), mediaAsset('assets/look-01.webp')], videos: [],
  },
]

export const getProductOptions = (product, key) => {
  const values = Array.isArray(product?.[key]) ? product[key] : []
  return [...new Set(values
    .filter((value) => typeof value === 'string' || typeof value === 'number')
    .map((value) => String(value).trim())
    .filter((value) => value && !/^EDITABLE_/i.test(value)))]
}

export const formatPrice = (price, lang = 'en') => {
  if (price === null || price === undefined) return lang === 'ar' ? 'السعر عند التأكيد' : 'Price on confirmation'
  return new Intl.NumberFormat(lang === 'ar' ? 'ar-EG' : 'en-EG').format(price) + (lang === 'ar' ? ' جنيه مصري' : ' EGP')
}
