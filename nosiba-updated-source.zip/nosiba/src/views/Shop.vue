<script setup>
import { computed, onMounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useLanguage } from '../composables/useLanguage.js'
import { useProducts } from '../composables/useProducts.js'
import ProductGrid from '../components/ProductGrid.vue'
import ProductFilters from '../components/ProductFilters.vue'

const route = useRoute()
const { t } = useLanguage()
const model = useProducts()
const { filteredProducts, categories, sizes, colors, category, color, size, availability, priceCap, sort, resetFilters } = model
const filtersApplied = computed(() => [category.value, color.value, size.value, availability.value, priceCap.value].some((value) => value !== 'all'))
const syncCategoryQuery = () => {
  const requestedCategory = route.query.category
  if (typeof requestedCategory === 'string' && categories.value.includes(requestedCategory)) category.value = requestedCategory
}

onMounted(() => {
  document.title = 'Nosiba — Shop'
  syncCategoryQuery()
})
watch(() => route.query.category, syncCategoryQuery)
</script>

<template>
  <div>
    <section class="page-hero">
      <div class="container-wide">
        <span class="section-eyebrow">{{ t('The catalog', 'الكتالوج') }}</span>
        <h1 class="mt-3">{{ t('Shop the edit.', 'تسوقي الاختيارات.') }}</h1>
        <p>{{ t('Prototype records are shown for layout review and will be replaced with verified Nosiba product data.', 'تظهر سجلات تجريبية لمراجعة التصميم وسيتم استبدالها ببيانات نُسيبه المؤكدة.') }}</p>
      </div>
    </section>

    <section class="section-pad">
      <div class="container-wide catalog-layout">
        <ProductFilters :model="model" :categories="categories" :sizes="sizes" :colors="colors" />
        <div>
          <div class="shop-toolbar justify-content-end">
            <div class="d-flex align-items-center gap-2">
              <button class="btn btn-outline-nosiba d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileFilters">{{ t('Filters', 'تصفية') }}</button>
              <select v-model="sort" class="select-clean" :aria-label="t('Sort products', 'ترتيب المنتجات')">
                <option value="featured">{{ t('Featured', 'مختارات') }}</option>
                <option value="newest">{{ t('Newest', 'الأحدث') }}</option>
                <option value="price-low">{{ t('Price: low to high', 'السعر: من الأقل') }}</option>
                <option value="price-high">{{ t('Price: high to low', 'السعر: من الأعلى') }}</option>
              </select>
            </div>
          </div>
          <div class="d-flex justify-content-between align-items-center mb-3">
            <span class="muted small">{{ filteredProducts.length }} {{ t('prototype pieces', 'قطع تجريبية') }}</span>
            <button v-if="filtersApplied" class="btn btn-link text-muted p-0 small" type="button" @click="resetFilters">{{ t('Clear all filters', 'مسح كل الفلاتر') }}</button>
          </div>
          <ProductGrid :products="filteredProducts" />
        </div>
      </div>
    </section>

    <div id="mobileFilters" class="offcanvas offcanvas-end" tabindex="-1">
      <div class="offcanvas-header">
        <h2 class="serif h3 mb-0">{{ t('Filters', 'تصفية') }}</h2>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body"><ProductFilters :model="model" :categories="categories" :sizes="sizes" :colors="colors" /></div>
    </div>
  </div>
</template>
